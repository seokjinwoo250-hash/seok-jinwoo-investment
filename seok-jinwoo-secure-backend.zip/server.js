import "dotenv/config";
import express from "express";
import session from "express-session";
import connectPg from "connect-pg-simple";
import pg from "pg";
import argon2 from "argon2";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const { Pool } = pg;

const required = ["DATABASE_URL", "SESSION_SECRET"];
for (const key of required) {
  if (!process.env[key]) throw new Error(`${key} is required`);
}
if (process.env.NODE_ENV === "production" && process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be at least 32 characters in production");
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_SSL === "true" ? { rejectUnauthorized: false } : undefined
});

await pool.query(`
CREATE TABLE IF NOT EXISTS members (
  id BIGSERIAL PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  access_code_hash TEXT NOT NULL UNIQUE,
  currency CHAR(3) NOT NULL DEFAULT 'EUR',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
)`);

const PgStore = connectPg(session);

app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"]
    }
  },
  referrerPolicy: { policy: "strict-origin-when-cross-origin" }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));

app.use(session({
  store: new PgStore({
    pool,
    tableName: "user_sessions",
    createTableIfMissing: true
  }),
  name: "sj.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many authentication attempts. Try again later." }
});

const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many account-creation attempts. Try again later." }
});

function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function validCurrency(value) {
  return ["EUR","USD","GBP","CHF","CAD","AUD","JPY","NGN","KRW"].includes(value);
}

function makeAccessCode() {
  const bytes = crypto.randomBytes(8);
  return `SJ-${bytes.toString("hex").slice(0,4).toUpperCase()}-${bytes.toString("hex").slice(4,8).toUpperCase()}`;
}

async function uniqueAccessCode() {
  for (;;) {
    const code = makeAccessCode();
    const hash = await argon2.hash(code);
    // A random code collision is extraordinarily unlikely. We still rely on
    // the database uniqueness constraint as the final guard.
    return { code, hash };
  }
}

function requireAuth(req, res, next) {
  if (!req.session.memberId) return res.status(401).json({ error: "Authentication required." });
  next();
}

app.post("/api/signup", signupLimiter, async (req, res) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = String(req.body.password || "");
    const currency = String(req.body.currency || "EUR").toUpperCase();

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: "Enter a valid email address." });
    }
    if (password.length < 12 || password.length > 128) {
      return res.status(400).json({ error: "Password must be 12–128 characters." });
    }
    if (!validCurrency(currency)) {
      return res.status(400).json({ error: "Unsupported currency." });
    }

    const passwordHash = await argon2.hash(password, {
      type: argon2.argon2id,
      memoryCost: 19456,
      timeCost: 2,
      parallelism: 1
    });
    const { code, hash: codeHash } = await uniqueAccessCode();

    const result = await pool.query(
      `INSERT INTO members(email,password_hash,access_code_hash,currency)
       VALUES($1,$2,$3,$4)
       RETURNING id,email,currency,created_at`,
      [email, passwordHash, codeHash, currency]
    );

    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "Could not create secure session." });
      req.session.memberId = result.rows[0].id;
      req.session.save(saveErr => {
        if (saveErr) return res.status(500).json({ error: "Could not save secure session." });
        res.status(201).json({
          member: result.rows[0],
          accessCode: code,
          warning: "Store this access code securely. It is shown only at account creation."
        });
      });
    });
  } catch (err) {
    if (err.code === "23505") return res.status(409).json({ error: "An account with that email already exists." });
    console.error(err);
    res.status(500).json({ error: "Account creation failed." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = String(req.body.password || "");
    const result = await pool.query(
      `SELECT id,email,password_hash,currency,created_at FROM members WHERE email=$1`,
      [email]
    );

    if (!result.rowCount) return res.status(401).json({ error: "Invalid email or password." });
    const member = result.rows[0];
    const ok = await argon2.verify(member.password_hash, password);
    if (!ok) return res.status(401).json({ error: "Invalid email or password." });

    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "Could not create secure session." });
      req.session.memberId = member.id;
      req.session.save(saveErr => {
        if (saveErr) return res.status(500).json({ error: "Could not save secure session." });
        res.json({
          member: {
            id: member.id,
            email: member.email,
            currency: member.currency,
            created_at: member.created_at
          }
        });
      });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed." });
  }
});

app.get("/api/me", requireAuth, async (req, res) => {
  const result = await pool.query(
    `SELECT id,email,currency,created_at FROM members WHERE id=$1`,
    [req.session.memberId]
  );
  if (!result.rowCount) return res.status(401).json({ error: "Account not found." });
  res.json({ member: result.rows[0] });
});

app.post("/api/logout", requireAuth, (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: "Logout failed." });
    res.clearCookie("sj.sid", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax"
    });
    res.status(204).end();
  });
});

app.get("/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true });
  } catch {
    res.status(503).json({ ok: false });
  }
});

app.use(express.static(path.join(__dirname, "public"), {
  extensions: ["html"],
  maxAge: process.env.NODE_ENV === "production" ? "1h" : 0
}));

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Unexpected server error." });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Seok Jinwoo server listening on ${port}`));
