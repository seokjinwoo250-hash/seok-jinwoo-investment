# Seok Jinwoo secure deployment

## What this package provides
- Node.js/Express backend
- PostgreSQL database
- Argon2id password hashing
- Server-side sessions stored in PostgreSQL
- HttpOnly + SameSite cookies
- Secure cookies in production
- Session regeneration after login/signup
- Authentication rate limiting
- Helmet security headers
- Caddy reverse proxy with automatic HTTPS certificates

## Before going live
1. Buy/use a domain that you control.
2. Point the domain's A/AAAA DNS records to the server.
3. Install Docker and Docker Compose on the server.
4. Copy `.env.example` to `.env`.
5. Set DOMAIN and ACME_EMAIL.
6. Generate a strong random POSTGRES_PASSWORD and SESSION_SECRET.
7. Run `docker compose up -d --build`.
8. Confirm `https://your-domain.example/health` returns `{"ok":true}`.
9. Test account creation, login, logout and session expiry.
10. Configure backups, monitoring, security updates and a documented incident-response process.

Caddy obtains and renews a trusted TLS certificate automatically when the DNS records
resolve to the server and ports 80/443 are reachable.

## Important
This package does not process deposits, investment transactions, or payment cards.
Before accepting real client money or offering regulated investment services, obtain
the legal/regulatory permissions and disclosures required for every jurisdiction served.
