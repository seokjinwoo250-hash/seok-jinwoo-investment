CREATE TABLE IF NOT EXISTS members (
  id BIGSERIAL PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  access_code_hash TEXT NOT NULL UNIQUE,
  currency CHAR(3) NOT NULL DEFAULT 'EUR',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS members_email_idx ON members(email);
CREATE INDEX IF NOT EXISTS members_access_code_idx ON members(access_code_hash);
